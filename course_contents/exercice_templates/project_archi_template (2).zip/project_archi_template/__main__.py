

import server.connection



if __name__ == '__main__':
    server.connection.run()