

from termgamelib.terminalgame import TerminalGame

class ConnectFour( TerminalGame ):
    pass